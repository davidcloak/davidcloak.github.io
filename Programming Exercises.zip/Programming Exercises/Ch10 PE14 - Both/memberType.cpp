#include "memberType.h"

memberType::memberType()
{
}

memberType::memberType(string fname, string lname, int booksBought, double spent)
{
	this->fname = fname;
	this->lname = lname;
	this->booksBought = booksBought;
	this->amountSpent = spent;
	makeID();
}

void memberType::setfname(string fname)
{
	this->fname = fname;
}

string memberType::getfname()
{
	return fname;
}

void memberType::setlname(string lname)
{
	this->lname = lname;
}

string memberType::getlname()
{
	return lname;
}

void memberType::makeID()
{
	this->id = fname.at(0) + lname + to_string(rand());
}

//for existing members when read from file
void memberType::setID(string id) {
	this->id = id;
}

string memberType::getID()
{
	return id;
}

void memberType::setBooksBought(int books)
{
	this->booksBought = books;
}

int memberType::getBooksBought()
{
	return booksBought;
}

void memberType::setAmountSpent(double spent)
{
	this->amountSpent = spent;
}

double memberType::getAmountSpent()
{
	return amountSpent;
}
