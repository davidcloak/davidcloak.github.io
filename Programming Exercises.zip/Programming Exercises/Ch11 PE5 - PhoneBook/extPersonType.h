#pragma once
#include "personType.h"
#include "addressType.h"
#include "dateType.h"
#include <iostream>
#include <string>
using namespace std;
class extPersonType :
	public personType,
	public addressType,
	public dateType
{
protected:
	bool family, friends, bussiness;
	string number;

public:
	extPersonType();

	extPersonType(string fname, string lname, string number);
	extPersonType(string fname, string lname, int i, string number, int day, int month, int year, string street, string city, string state, int zip);

	void setNumber(int num) {
		this->number = num;
	}
	string getNumber() {
		return number;
	}
	void setRelation(int i);
	int getRelationNum();
	string getRelation();

	//extPersonType[] sort(extPersonType sorting[], int length; int doWhat);

	string toString();
	string toFile();

};

