#include "bookType.h"
using namespace std;
bookType::bookType(string title, string publisher, int stock, string ISBN, double cost)
{
	this->title = title;
	this->publisher = publisher;
	this->numOfCopyStock = stock;
	this->isbn = ISBN;
	this->cost = cost;
}

void bookType::setTitle(string title)
{
	this->title = title;
}

string bookType::getTitle()
{
	return title;
}

void bookType::setPublisher(string publisher)
{
	this->publisher = publisher;
}

string bookType::getPublisher()
{
	return publisher;
}

void bookType::setStockAmount(int stock)
{
	this->numOfCopyStock = stock;
}

int bookType::getStockAmount()
{
	return numOfCopyStock;
}

void bookType::setISBN(string ISBN)
{
	this->isbn = ISBN;
}

string bookType::getISBN()
{
	return isbn;
}

void bookType::setCost(double cost)
{
	this->cost = cost;
}

double bookType::getCost()
{
	return cost;
}

void bookType::addAuthor(string author)
{
	if (position < 4) {
		this->author[position] = author;
		position++;
	}
	else {
		//std::cout << "Can't add anymore authors" << std::endl;
	}
}

string bookType::getAuthors()
{
	string authors = "";

	for (int x = 0; x < position; x++) {
		authors += author[x] + " ";
	}

	return authors;
}
