// BookExercise.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "bookType.h"
#include <fstream>
using namespace std;

void readBooks();
int searchTitle(string title);
int searchISBN(string isbn);
void updateStock(int change, int where);

ifstream fin;
bookType books[6];


string title, publisher, author, isbn;
int stock, numberOfAuthors;
double cost;
int position = 0;

int main()
{
    readBooks();
    int choose;
    string title, isbn;
    int update;
    int where = 0;
    bool flag = true;
    
    while (flag) {
        cout << "Search by title 1, Search By ISBN 2, Update books in stock of pervous search 3, To exit 9 >>";
        cin >> choose;

        switch (choose) {
        case 1:
            cout << "Enter the title you want to seach by (use \"_\" for spaces) >>";
            cin >> title;
            where = searchTitle(title);
            cout << books[where].toString() << endl;
            break;
        case 2:
            cout << "Enter the ISBN";
            cin >> isbn;
            where = searchISBN(isbn);
            cout << books[where].toString() << endl;
            break;
        case 3:
            cout << books[where].getTitle() << " registered stock " << books[where].getStockAmount() << endl;
            cout << "Enter the change. If its a decreaes use a \"-\" >>";
            cin >> update;
            updateStock(update, where);
            cout << "New Stock " << books[where].getStockAmount() << endl;
            break;
        case 9:
            flag = false;
            cout << "Bye Bye" << endl;
            break;
        default:
            cout << "Not a option try again.";
            break;
        }
    }

}

int searchTitle(string title)
{
    int position;

    for (int i = 0; i < 10; i++) {
        if (books[i].getTitle() == title) {
            position = i;
        }
    }

    return position;
}

int searchISBN(string isbn)
{
    int position;

    for (int i = 0; i < 10; i++) {
        if (books[i].getISBN() == isbn) {
            position = i;
        }
    }

    return position;
}

void updateStock(int change, int where) 
{
    if ((books[where].getStockAmount()+change) >= 0) {//plus a negative will still subract making sure you don't have negative stock
        books[where].setStockAmount(books[where].getStockAmount() + change);// ^
    }
}

void readBooks() {
    fin.open("booktext.txt");

    if (fin.is_open()) {
        while (!fin.eof()) {
            fin >> title >> publisher >> stock >> isbn >> cost >> numberOfAuthors;
            bookType book(title, publisher, stock, isbn, cost);
            books[position] = book;

            for (int i = 0; i < numberOfAuthors; i++) {
                fin >> author;
                books[position].addAuthor(author);
            }

            position++;
        }
    }
    else {
        cout << "file did not open";
    }

    fin.close();
}//title publisher stock isbn cost numberOfAuthors {authors}