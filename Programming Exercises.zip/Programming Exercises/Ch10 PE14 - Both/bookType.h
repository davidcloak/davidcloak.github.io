#pragma once
#include <string>
using namespace std;
class bookType
{
protected:
	string title, publisher, isbn;
	string author[4];
	int numOfCopyStock;
	double cost;
	int position = 0;
public:
	bookType();

	bookType(string title, string publisher, int stock, string ISBN, double cost);//constructor

	void setTitle(string title);//sets title
	string getTitle();//gets title
	void setPublisher(string publisher);//sets publisher
	string getPublisher();//gets the publisher
	void setStockAmount(int stock);// sets the amount of books in stock
	int getStockAmount();// gets the amount of books in stock
	void setISBN(string ISBN);//sets the ISBN
	string getISBN();//gets the ISBN
	void setCost(double cost);//sets the cost
	double getCost();//gets the cost

	void addAuthor(string author);//adds a new author lastnames up to four
	string getAuthors();//gets all authors last names
	int getNumOfAuthors();

	//to string default info on class
	string toString() {
		return title + " by " + getAuthors() + " published by " + publisher + " ISBN:" + isbn;
	}
	
};


