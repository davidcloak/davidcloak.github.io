#include "extPersonType.h"
#include "addressType.h"
#include "dateType.h"

extPersonType::extPersonType() : personType("", ""), dateType(0, 0, 0), addressType("null", "null", "null", 0)
{
}

extPersonType::extPersonType(string fname, string lname, string number):personType(fname, lname), dateType(0, 0, 0), addressType("null", "null", "null", 0)
{
	this->number = number;
	family = false;
	friends = false;
	bussiness = false;
}

extPersonType::extPersonType(string fname, string lname, int i, string number, int day, int month, int year, string street, string city, string state, int zip) : personType(fname, lname), dateType(day, month, year), addressType(street, city, state, zip)
{
	this->number = number;
	if (i == 1) {
		family = true;
		friends = false;
		bussiness = false;
	}
	else if (i == 2) {
		friends = true;
		family = false;
		bussiness = false;
	}
	else if (i == 3) {
		bussiness = true;
		family = false;
		friends = false;
	}
	else {
		family = false;
		friends = false;
		bussiness = false;
	}
}

void extPersonType::setRelation(int i)
{
	if (i == 1) {
		family = true;
		friends = false;
		bussiness = false;
	}
	else if (i == 2) {
		friends = true;
		family = false;
		bussiness = false;
	}
	else if (i == 3) {
		bussiness = true;
		family = false;
		friends = false;
	}
}

int extPersonType::getRelationNum()
{
	if (family) {
		return 1;
	}
	else if (friends) {
		return 2;
	}
	else if (bussiness) {
		return 3;
	}
	else {
		return 0;
	}
}

string extPersonType::getRelation()
{
	if (family) {
		return "family";
	}
	else if (friends) {
		return "friend";
	}
	else if (bussiness) {
		return "bussiness";
	}
}

string extPersonType::toString()
{
	string output;

	if (addressType::getZip() != 0) {
		output = personType::toString() + " number: " + number + "\n   " + dateType::toString() + "\n   " + addressType::toString();
	}
	else {
		output = personType::toString() + " number: " + number;
	}

	return output;
}

string extPersonType::toFile()
{
	string output;

	output = personType::toString() +" "+to_string(getRelationNum())+" "+ number+ " " + dateType::toFile() + " " + addressType::toFile();

	return output;
}
//fname, lname, relationNum, number, day, month, year, street, city, state, zip