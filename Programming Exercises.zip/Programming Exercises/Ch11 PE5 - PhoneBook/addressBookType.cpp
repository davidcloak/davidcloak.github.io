// PhoneBookExercise.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
#include <fstream>
#include "extPersonType.h"

void readFile();
void writeFile();
void addContact();
void viewContacts();
void sort(int length, int byWhat);

extPersonType contacts[500];
int position = 0;
ifstream fin;
ofstream fout;

string fname, lname, street, city, state, relation, number;
int zip, day, month, year, relationNum;
char yesNo;

int choice;
bool flag = true;

int main()
{
    readFile();
    while (flag) {
        cout << "Contact Menu" << endl;
        cout << "Enter 1 to add new contact" << endl;
        cout << "Enter 2 to get contact list" << endl;
        cout << "Enter 3 to sort by first name" << endl;
        cout << "Enter 4 to sort by last name" << endl;
        cout << "Enter 9 to exit." << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
            system("cls");
            addContact();
            break;
        case 2:
            system("cls");
            viewContacts();
            break;
        case 3:
            system("cls");
            sort(position, 1);
            break;
        case 4:
            system("cls");
            sort(position, 2);
            break;
        case 9:
            flag = false;
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Not an option." << endl;
            break;
        }
    }

    writeFile();
}

void addContact() {
    cout << "To start enter first name, last name, and number >>";
    cin >> fname >> lname >> number;
    cout << "Do you want to enter their address, relation, and birth date? y/n >>";
    cin >> yesNo;
    if (yesNo == 'y') {
        cout << "Enter their street address, city, state, and zip (No spaces in between names ex Ford_City) >>";
        cin >> street >> city >> state >> zip;
        cout << "Enter what their relation is to you friend, family, bussiness >>";
        cin >> relation;
        cout << "Enter the birth day, birth month, birth year >>";
        cin >> day >> month >> year;

        if (relation == "family") {
            relationNum = 1;
        }
        else if (relation == "friend") {
            relationNum = 2;
        }
        else if (relation == "bussiness") {
            relationNum = 3;
        }
        //cout << position << endl;
        contacts[position] = extPersonType(fname, lname, relationNum, number, day, month, year, street, city, state, zip);
        position++;
        //cout << position << endl;
    }
    else {
        //cout << position << endl;
        contacts[position] = extPersonType(fname, lname, number);
        position++;
        //cout << position << endl;
    }
}

void viewContacts() {
    for (int i = 0; i < position; i++) {
        cout << contacts[i].toString() << endl;
    }
}

void readFile() {
    fin.open("contacts.txt");
    if (fin.is_open()) {
        while (!fin.eof()) {
            fin >> fname >> lname >> relationNum >> number >> day >> month >> year >> street >> city >> state >> zip;
            contacts[position] = extPersonType(fname, lname, relationNum, number, day, month, year, street, city, state, zip);
            position++;
        }
        position--;
    }
    else {
        cout << "file could not be opened" << endl;
    }
    fin.close();
}

void writeFile() {
    fout.open("contacts.txt");
    if (fout.is_open()) {
        for (int i = 0; i < position; i++) {
            fout << contacts[i].toFile() << endl;
        }
    }
    else {
        cout << "file did not open" << endl;
    }
    fout.close();
}

void sort(int length, int byWhat) {


    if (byWhat == 1) {
        //by first name
        for (int x = 0; x < length; x++) {
            for (int y = 0; y < length - 1 - x; y++) {
                if (contacts[y].getfname() > contacts[y+1].getfname()) {
                    extPersonType temp;
                    temp = contacts[y];
                    contacts[y] = contacts[y+1];
                    contacts[y+1] = temp;
                }
            }
        }
    }
    else {
        //by last name
        for (int x = 0; x < length; x++) {
            for (int y = 0; y < length - 1 - x; y++) {
                if (contacts[y].getlname() > contacts[y + 1].getlname()) {
                    extPersonType temp;
                    temp = contacts[y];
                    contacts[y] = contacts[y+1];
                    contacts[y+1] = temp;
                }
            }
        }
    }
}