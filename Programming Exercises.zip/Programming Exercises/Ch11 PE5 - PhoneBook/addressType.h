#pragma once
#include <iostream>
#include <string>
using namespace std;
class addressType
{
protected:
	string street;
	string city;
	string state;
	int zip;

public:
	addressType(string street, string city, string state, int zip);

	void setStreet(string street);
	void setCity(string city);
	void setState(string state);
	void setZip(int zip);
	string getStreet();
	string getCity();
	string getState();
	int getZip();

	string toString();
	string toFile() {
		return street + " " + city + " " + state + " " + to_string(zip);
	}
};

