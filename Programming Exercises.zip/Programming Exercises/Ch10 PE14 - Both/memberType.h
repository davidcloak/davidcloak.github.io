#pragma once
#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
class memberType
{
protected:
	string fname, lname;
	string id;
	int booksBought;
	double amountSpent;

public:
	memberType();

	memberType(string fname, string lname, int booksBought, double spent);

	void setfname(string fname);//sets the first name
	string getfname();// gets first name
	void setlname(string lname);//sets last name
	string getlname();//gets last name
	void makeID();// makes id first Initial of first name last name random number
	void setID(string id);
	string getID();//gets id
	void setBooksBought(int books);//sets the number of books bought
	int getBooksBought();//gets the number of books bought
	void setAmountSpent(double spent);//amount spent based on books bought
	double getAmountSpent();//gets amount spent

	//returns the person whole name
	string wholeName() {
		return fname + " " + lname;
	}

	//my toString current no use
	string toString() {
		return "";
	}
};

