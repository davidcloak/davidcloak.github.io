#include "personType.h"

void personType::setfname(string fname)
{
	this->fname = fname;
}

string personType::getfname()
{
	return fname;
}

void personType::setlname(string lname)
{
	this->lname = lname;
}

string personType::getlname()
{
	return lname;
}

//void personType::sort(personType sorting[], int length, int byWhat)
//{
//
//}
