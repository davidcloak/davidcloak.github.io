// BookStore.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include "memberType.h"
#include "bookType.h"
using namespace std;

void readBooks();//also used for members
void booksOut();//also used for members
void changeName(string fname, string lname);
void updateBooksBoughtAndAmountSpent(int addition, int whatBook);
int searchTitle(string title);
int searchISBN(string isbn);
void memberSearch(string ID);
void memberMenu();
void newMember();
void newBook();
void updateStock(int change, int where);
void discount(int whatBook);

memberType members[500];
bookType books[1000];

ifstream fin;
ofstream fout;
//book
string title, publisher, isbn, author;
int stock, numberOfAuthors;
double cost;
//member
string fname, lname, id;
int booksBought;
double amountSpent;

int memberPosition, bookPosition;
int memberLength, whatBook;

int choice;
bool mainFlag = true;
bool memberFlag = false;
string memberID;

int main()
{
    readBooks();
    
    while (mainFlag) {
        cout << "(1) to add a new title to inventory." << endl;
        cout << "(2) update the stock of a book." << endl;
        cout << "(3) new member." << endl;
        cout << "(4) Log in." << endl;
        cout << "(9) to exit." << endl;
        cout << "Enter your choice >>";
        cin >> choice;

        switch (choice) {
        case 1:
            system("cls");
            newBook();
            break;
        case 2:
            system("cls");
            whatBook = -1;
            cout << "How do you want to find the book by title (1) or ISBN(2) >>";
            cin >> choice;
            cin.ignore(120, '\n');
            if (choice == 1) {
                cout << "Enter the title (Use \'_\' for spaces)>>";
                cin >> title;
                cin.ignore(120, '\n');
                whatBook = searchTitle(title);
            }
            else if (choice == 2) {
                cout << "Enter the ISBN >>";
                cin >> isbn;
                cin.ignore(120, '\n');
                whatBook = searchISBN(isbn);
            }
            if (whatBook != -1) {
                cout << books[whatBook].getTitle() << " registered stock " << books[whatBook].getStockAmount() << endl;
                cout << "Enter the change. If its a decreaes use a \"-\" >>";
                cin >> stock;
                updateStock(stock, whatBook);
                cin.ignore(120, '\n');
            }
            else {
                cout << "That book could not be found." << endl;
            }
            break;
        case 3:
            newMember();
            break;
        case 4:
            system("cls");
            cout << "Enter your ID >>";
            cin >> memberID;
            memberSearch(memberID);
            cin.ignore();
            if (memberFlag) {
                system("cls");
                memberMenu();
            }
            else {
                cout << "Member ID could not be found." << endl;
            }
            break;
        case 9:
            mainFlag = false;
            cout << "bye bye";
            break;
        default:
            cout << "That is not an option try again." << endl;
            break;
        }
    }//menu end


    booksOut();
}//main end

//menu for members 
void memberMenu() {
    while (memberFlag) {
        cout << "Enter 1 to Change Your name" << endl;
        cout << "Enter 2 to buy a book" << endl;
        cout << "Enter 3 for a list of all the books" << endl;
        cout << "Enter 4 to sign out." << endl;
        cout << ">>";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter what your first and last names are now >>";
            cin >> fname >> lname;
            changeName(fname, lname);
            system("cls");
            cout << "Your new ID is: " << members[memberPosition].getID() << endl;
            break;
        case 2:
            system("cls");
            whatBook = -1;
            cout << "How do you want to find the book by title (1) or ISBN(2) >>";
            cin >> choice;
            cin.ignore(120, '\n');
            if (choice == 1) {
                cout << "Enter the title (Use \'_\' for spaces)>>";
                cin >> title;
                cin.ignore(120, '\n');
                whatBook = searchTitle(title);
            }
            else if (choice == 2) {
                cout << "Enter the ISBN >>";
                cin >> isbn;
                cin.ignore(120, '\n');
                whatBook = searchISBN(isbn);
            }
            if (whatBook == -1) {
                cout << "Sorry that book could not be found." << endl;
            }
            else {
                cout << books[whatBook].toString() << endl;
                cout << "Would you like to buy this book (1) for yes, (2) for no. >> ";
                cin >> choice;
                if (choice == 1) {
                    updateBooksBoughtAndAmountSpent(1, whatBook);
                }
            }
            break;
        case 3:
            system("cls");
            for (int i = 0; i < bookPosition; i++) {
                cout << books[i].toString() << endl;
            }
            break;
        case 4:
            memberFlag = false;
            system("cls");
            break;
        default:
            cout << "Not an option." << endl;
            break;
        }
    }
}


//adds new book to the books array
void newBook() {
    //cout << to_string(bookPosition) << endl;
    cout << "Dont use spaces use \"_\" for space in names" << endl;
    cout << "Enter the title, publisher, stock of the book, ISBN, cost, and the number of authors \n>>";
    cin >> title >> publisher >> stock >> isbn >> cost >> numberOfAuthors;
    cin.ignore(120, '\n');
    bookType book(title, publisher, stock, isbn, cost);
    books[bookPosition] = book;

    for (int i = 0; i < numberOfAuthors; i++) {
        cout << "Authors name still use \"_\' for spaces >>";
        cin >> author;
        books[bookPosition].addAuthor(author);
    }

    bookPosition++;
    //cout << to_string(bookPosition) << endl;
}

//adds new members to the members array
void newMember() {
    cout << "Enter you first and last name >>";
    cin >> fname >> lname;
    memberType member(fname, lname, 0, 10);
    members[memberLength] = member;
    members[memberLength].makeID();
    memberPosition = memberLength;
    memberLength++;
    system("cls");
    cout << "Your id is: " << members[memberPosition].getID() << " Thank you for your $10 payment." << endl;
    memberFlag = true;
    memberMenu();
}


//searches for the member
void memberSearch(string ID) {
    int position = -1;

    for (int i = 0; i < memberLength; i++) {
        if (members[i].getID() == ID) {
            position = i;
        }
    }
    if (position != -1) {
        memberFlag = true;
    }

    memberPosition = position;
}



void changeName(string fname, string lname) {
    members[memberPosition].setfname(fname);
    members[memberPosition].setlname(lname);
    members[memberPosition].makeID();
    cout << "New name " << members[memberPosition].wholeName() << endl;
    cout << "Your new ID is " << members[memberPosition].getID() << endl;
}


//wow thats a long function name but tells you what it does
void updateBooksBoughtAndAmountSpent(int addition, int whatBook) {
    members[memberPosition].setBooksBought(members[memberPosition].getBooksBought() + addition);
    discount(whatBook);
    cout << "You have now bought a total of " << members[memberPosition].getBooksBought() << " and have spent " << setprecision(2) << fixed << members[memberPosition].getAmountSpent() << endl;
}

void discount(int whatBook) {
    double discount = 5;
    if (members[memberPosition].getBooksBought() % 11) {
        discount = members[memberPosition].getAmountSpent() / 10;
        discount = 1 - (discount / 100);
        members[memberPosition].setAmountSpent(0);
        cout << "Congrats that is the 11 book" << endl;
        cout << "Normal Prices is $" << books[whatBook].getCost()<<endl;
        cout << "While you paid $" << (books[whatBook].getCost() * discount) <<endl;

    }
    else {
        discount = 1 - (discount / 100);
        members[memberPosition].setAmountSpent(members[memberPosition].getAmountSpent() + (books[whatBook].getCost() * discount));
        cout << "Normal Prices is $" << books[whatBook].getCost() << endl;
        cout << "While you paid $" << (books[whatBook].getCost() * discount) << endl;
    }
}

int searchTitle(string title)
{
    cout << to_string(bookPosition) << endl;
    int position = -1;

    for (int i = 0; i < bookPosition; i++) {
        if (books[i].getTitle() == title) {
            position = i;
        }
    }

    return position;
}



int searchISBN(string isbn)
{
    int position = -1;

    for (int i = 0; i < bookPosition; i++) {
        if (books[i].getISBN() == isbn) {
            position = i;
        }
    }

    return position;
}




void updateStock(int change, int where)
{
    if ((books[where].getStockAmount() + change) >= 0) {//plus a negative will still subract making sure you don't have negative stock
        books[where].setStockAmount(books[where].getStockAmount() + change);// ^
    }
}




//reads from files
void readBooks() {
    fin.open("booktext.txt");

    if (fin.is_open()) {
        while (!fin.eof()) {
            fin >> title >> publisher >> stock >> isbn >> cost >> numberOfAuthors;
            bookType book(title, publisher, stock, isbn, cost);
            books[bookPosition] = book;

            for (int i = 0; i < numberOfAuthors; i++) {
                fin >> author;
                books[bookPosition].addAuthor(author);
            }

            bookPosition++;
        }
        bookPosition--;
    }
    else {
        cout << "book file in did not open";
    }

    fin.close();

    //members
    fin.open("membertext.txt");
    
    if (fin.is_open()) {
        while (!fin.eof()) {
            fin >> fname >> lname >> booksBought >> amountSpent >> id;
            memberType member(fname, lname, booksBought, amountSpent);
            members[memberLength] = member;
            members[memberLength].setID(id);

            memberLength++;
        }
        memberLength--;
    }
    else {
        cout << "member file in did not open";
    }

    fin.close();
}

//save any added book or members
void booksOut() {
    fout.open("booktext.txt");

    if (fout.is_open()) {

        for (int i = 0; i < bookPosition; i++) {
            fout << books[i].getTitle() << " " << books[i].getPublisher() << " " 
                << books[i].getStockAmount() << " " << books[i].getISBN() << " " << books[i].getCost() << " "
                << books[i].getNumOfAuthors() << " " << books[i].getAuthors() << endl;
        }
    }
    else {
        cout << "book file out has not been opened" << endl;
    }

    fout.close();

    fout.open("membertext.txt");

    if (fout.is_open()) {

        for (int i = 0; i < memberLength; i++) {
            fout << members[i].getfname() << " " << members[i].getlname() << " "<< members[i].getBooksBought()<< " "<< members[i].getAmountSpent()<<" "<< members[i].getID() << endl;
        }
    }
    else {
        cout << "member file out has not been opened" << endl;
    }

    fout.close();
}
