#pragma once
#include <iostream>
#include <string>
using namespace std;
class personType
{
protected:
	string fname;
	string lname;

public:
	personType(string fname, string lname) {
		this->fname = fname;
		this->lname = lname;
	}

	void setfname(string fname);
	string getfname();
	void setlname(string lname);
	string getlname();

	//void sort(personType sorting[], int length, int byWhat);

	string toString() {
		return fname + " " + lname;
	}
};

