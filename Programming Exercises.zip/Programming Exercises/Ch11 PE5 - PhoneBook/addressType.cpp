#include "addressType.h"

addressType::addressType(string street, string city, string state, int zip)
{
	this->street = street;
	this->city = city;
	this->state = state;
	this->zip = zip;
}

void addressType::setStreet(string street)
{
	this->street = street;
}

void addressType::setCity(string city) {
	this->city = city;
}

void addressType::setState(string state) {
	this->state = state;
}

void addressType::setZip(int zip) {
	this->zip = zip;
}

string addressType::getStreet() {
	return street;
}

string addressType::getCity() {
	return city;
}

string addressType::getState() {
	return state;
}

int addressType::getZip() {
	return zip;
}

string addressType::toString()
{
	return "Address: " + street + " " + city + " " + state + " " + to_string(zip);
}
