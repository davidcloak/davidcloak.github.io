// MemberExercise.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "memberType.h"
#include <iomanip>
using namespace std;

void changeName(string fname, string lname);
void updateBooksBoughtAndAmountSpent(int addition);

memberType member("David", "Cloak", 6);
                //first     last   startingBooks

int main()
{
    int choice;
    bool flag = true;
    string fname, lname;
    int addition;

    while (flag) {
        cout << "If you changed your name enter 1, if you bought more books enter 2, to exit enter 9 >>";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter your changed full name >> ";
            cin >> fname >> lname;
            changeName(fname, lname);
            break;
        case 2:
            cout << "Enter how many books you have bought since last time >> ";
            cin >> addition;
            updateBooksBoughtAndAmountSpent(addition);
            break;
        case 9:
            flag = false;
            cout << "Thank you! " << member.wholeName() << endl;
            cout << "bye bye";
            break;
        default:
            cout << "Not an option try again." << endl;
            break;
        }
    }
}

void changeName(string fname, string lname) {
    member.setfname(fname);
    member.setlname(lname);
    member.makeID();
    cout << "New name " << member.wholeName() << endl;
    cout << "Your new ID is " << member.getID() << endl;
}

//wow thats a long function name but tells you what it does
void updateBooksBoughtAndAmountSpent(int addition) {
    member.setBooksBought(member.getBooksBought()+addition);
    member.setAmountSpent();
    cout << "You have now bought a total of " << member.getBooksBought() << " and have spent " << setprecision(2) << fixed << member.getAmountSpent()<<endl;
}
