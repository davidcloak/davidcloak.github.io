/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsonlecture;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;


/**
 *
 * @author wanda
 */
public class JSONLecture {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ObjectMapper mapper = new ObjectMapper();
        Recipe pbj = new Recipe();
        pbj.setRecipeName("Peanut Buter and Jelly");
        pbj.setCalories(189);
        pbj.setAllergyWarning(true);
        pbj.setIngredients(Arrays.asList("2 bread", "Peanut Butter", "Jelly"));
        Map<String, String> theSteps = new HashMap(){{
            put("Step1", "Put bread on plate");
            put("Step2", "Spread stuff on bread");
            put("Step2", "Close sandwich");
        }};
        pbj.setSteps(theSteps);
        
        try{
            String JSON = mapper.writeValueAsString(pbj);
            //String JSON = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(pbj);
            mapper.writeValue(new File("C:\\Users\\wanda\\Desktop\\David\\worhees.json"), pbj);
            System.out.println(JSON);
        }catch(Exception ex){
            System.out.println("JSON String failed "+ex.toString());
        }
    }
    
}
