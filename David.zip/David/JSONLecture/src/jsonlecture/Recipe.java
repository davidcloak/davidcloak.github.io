/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsonlecture;
import java.util.List;
import java.util.Map;

/**
 *
 * @author wanda
 */
public class Recipe {
    private String recipeName;
    private int calories;
    private List<String> ingredients;
    private Map<String, String> steps;
    private boolean allergyWarning;

    public Recipe() {
    }

    public Recipe(String recipeName, int calories, List<String> ingredients, Map<String, String> steps, boolean allergyWarning) {
        this.recipeName = recipeName;
        this.calories = calories;
        this.ingredients = ingredients;
        this.steps = steps;
        this.allergyWarning = allergyWarning;
    }

    
    
    //setters and getter required for Jackson
    public String getRecipeName() {
        return recipeName;
    }

    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public Map<String, String> getSteps() {
        return steps;
    }

    public void setSteps(Map<String, String> steps) {
        this.steps = steps;
    }

    public boolean isAllergyWarning() {
        return allergyWarning;
    }

    public void setAllergyWarning(boolean allergyWarning) {
        this.allergyWarning = allergyWarning;
    }

    @Override
    public String toString() {
        return "Recipe{" + "recipeName=" + recipeName + ", calories=" + calories + ", ingredients=" + ingredients + ", steps=" + steps + ", allergyWarning=" + allergyWarning + '}';
    }
    
    
    
}
