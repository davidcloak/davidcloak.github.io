#include "dateType.h"

bool dateType::checkDate(int day, int month, int year)
{
    //needed for leep year day
    if (isLeepYear(year)) {
        Months[1] = 29;
    }
    if (year <= 2020) {
        if (month > 0 && month < 13) {
            if (day <= Months[month] && day > 0) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

bool dateType::isLeepYear(int year) {
    if (year % 4 == 0 && !year % 100 == 0) {
        return true;
    }
    else if (year % 100 == 0 && year % 400 == 0) {
        return true;
    }


    return false;
}

string dateType::toString()
{
    string output;

    output = "Birth Date: " + to_string(month) + "/" + to_string(day) + "/" + to_string(year);

    return output;
}
