#pragma once
#include <iostream>
#include <string>
using namespace std;
class dateType
{
protected:
	int month, day, year;
	int dayOfTheYear;
	int Months[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

public:
	dateType(int day, int month, int year) {
		Months[1] = 28;//makes sure by defualt Feburary is 28
		if (checkDate(day, month, year) == true) {
			setDate(day, month, year);
		}
		else {
			setDate(0, 0, 0);
		}
	}

	void setDate(int day, int month, int year) {
		this->day = day;
		this->month = month;
		this->year = year;
	}

	bool checkDate(int day, int month, int year);
	bool isLeepYear(int year);

	string toString();
	string toFile() {
		return to_string(day) + " " + to_string(month) + " " + to_string(year);
	}
};

