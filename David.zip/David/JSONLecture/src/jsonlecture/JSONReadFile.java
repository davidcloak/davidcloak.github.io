/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsonlecture;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
//Read in the datatypes MUST match
//Jackson has a problem with [] around JSON
//if your JSON has [] around it - two choices
//remove the first and last[]
//parse through the file using a foreach structure, each pull out a JSON string

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author wanda
 */
public class JSONReadFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            ObjectMapper mapper = new ObjectMapper();
            Recipe pbj = mapper.readValue(new File("C:\\Users\\wanda\\Desktop\\David\\worhees.json"), Recipe.class);
            System.out.println(pbj.getRecipeName());
            System.out.println(pbj.toString());
        }catch(Exception ex){
            System.out.println("Error"+ex.toString());
        }
    }
    
}//baeldung.com
